"""Event -> service mapping and helper constants (the \'policy config\')."""
from __future__ import annotations

from typing import Dict, List

# Human-friendly labels for each supported life event.
EVENT_LABELS: Dict[str, str] = {
    "child_birth": "Birth of a Child",
    "job_loss": "Job Loss",
    "retirement": "Retirement",
    "disability": "Disability",
    "marriage": "Marriage",
    "relocation": "Relocation",
    "death": "Death of a Family Member",
}

# Supported life events (used for validation).
LIFE_EVENTS: List[str] = list(EVENT_LABELS.keys())

# Sensitive events always require human oversight before finalization.
SENSITIVE_EVENTS: set[str] = {"death", "disability"}

# Core policy map: each event -> departments, ordered actions, required documents.
# record_key links a document to a citizen's existing records for auto-verification.
EVENT_SERVICE_MAP: Dict[str, Dict] = {
    "child_birth": {
        "departments": ["Identity", "Health", "Welfare", "Communication"],
        "actions": [
            {"department": "Identity", "action": "Register newborn and issue birth certificate"},
            {"department": "Health", "action": "Enroll child in national vaccination schedule"},
            {"department": "Welfare", "action": "Assess child benefit / maternity support eligibility"},
            {"department": "Communication", "action": "Notify parents of activated services"},
        ],
        "documents": [
            {"name": "Parent National ID", "record_key": "national_id"},
            {"name": "Hospital Proof of Birth", "record_key": None},
            {"name": "Address Proof", "record_key": "address_proof"},
        ],
    },
    "job_loss": {
        "departments": ["Welfare", "Tax", "Communication"],
        "actions": [
            {"department": "Welfare", "action": "Initiate unemployment allowance application"},
            {"department": "Tax", "action": "Adjust income tax withholding for lost income"},
            {"department": "Communication", "action": "Send support & re-skilling program info"},
        ],
        "documents": [
            {"name": "National ID", "record_key": "national_id"},
            {"name": "Employment Termination Letter", "record_key": None},
            {"name": "Bank Account Details", "record_key": "bank_details"},
        ],
    },
    "retirement": {
        "departments": ["Welfare", "Health", "Tax", "Communication"],
        "actions": [
            {"department": "Welfare", "action": "Activate pension disbursement"},
            {"department": "Health", "action": "Issue senior citizen health card"},
            {"department": "Tax", "action": "Apply senior citizen tax exemptions"},
            {"department": "Communication", "action": "Share retirement benefits summary"},
        ],
        "documents": [
            {"name": "National ID", "record_key": "national_id"},
            {"name": "Service / Employment Record", "record_key": "service_record"},
            {"name": "Bank Account Details", "record_key": "bank_details"},
        ],
    },
    "disability": {
        "departments": ["Health", "Welfare", "Identity", "Communication"],
        "actions": [
            {"department": "Health", "action": "Schedule medical disability assessment"},
            {"department": "Welfare", "action": "Initiate disability allowance application"},
            {"department": "Identity", "action": "Issue disability identity card"},
            {"department": "Communication", "action": "Notify citizen with support contacts"},
        ],
        "documents": [
            {"name": "National ID", "record_key": "national_id"},
            {"name": "Medical Certificate", "record_key": None},
            {"name": "Disability Assessment Report", "record_key": None},
        ],
    },
    "marriage": {
        "departments": ["Identity", "Tax", "Communication"],
        "actions": [
            {"department": "Identity", "action": "Register marriage and update civil records"},
            {"department": "Tax", "action": "Update tax profile for joint filing options"},
            {"department": "Communication", "action": "Confirm updated records to the couple"},
        ],
        "documents": [
            {"name": "National ID (both spouses)", "record_key": "national_id"},
            {"name": "Marriage Affidavit", "record_key": None},
        ],
    },
    "relocation": {
        "departments": ["Identity", "Health", "Education", "Communication"],
        "actions": [
            {"department": "Identity", "action": "Update registered address in civil records"},
            {"department": "Health", "action": "Transfer health records to new district"},
            {"department": "Education", "action": "Facilitate school transfer for dependents"},
            {"department": "Communication", "action": "Confirm new local services to citizen"},
        ],
        "documents": [
            {"name": "National ID", "record_key": "national_id"},
            {"name": "New Address Proof", "record_key": None},
        ],
    },
    "death": {
        "departments": ["Identity", "Welfare", "Tax", "Communication"],
        "actions": [
            {"department": "Identity", "action": "Register death and update civil records"},
            {"department": "Welfare", "action": "Initiate survivor / pension transfer benefits"},
            {"department": "Tax", "action": "Begin estate and tax account closure"},
            {"department": "Communication", "action": "Guide next of kin through remaining steps"},
        ],
        "documents": [
            {"name": "National ID of Deceased", "record_key": "national_id"},
            {"name": "Death Certificate", "record_key": None},
            {"name": "Next of Kin ID", "record_key": None},
        ],
    },
}
