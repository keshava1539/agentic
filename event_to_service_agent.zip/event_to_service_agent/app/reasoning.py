"""ReasoningEngine abstraction: offline MockLLM (default) + optional OpenAI adapter."""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, List

from app.config import settings


class ReasoningEngine(ABC):
    """Common interface so agents can reason without depending on any vendor."""

    name: str = "ReasoningEngine"

    @abstractmethod
    def generate(self, task: str, payload: Dict[str, Any]) -> str:
        """Produce natural-language text for a named task using the given payload."""
        raise NotImplementedError


class MockLLM(ReasoningEngine):
    """Deterministic, rule-based engine. Always works offline — the DEFAULT."""

    name = "MockLLM"

    def generate(self, task: str, payload: Dict[str, Any]) -> str:
        if task == "citizen_message":
            return self._citizen_message(payload)
        # Generic fallback keeps the abstraction robust for future tasks.
        return f"[MockLLM] No template for task '{task}'."

    @staticmethod
    def _citizen_message(payload: Dict[str, Any]) -> str:
        """Build a warm, plain-language summary for the citizen."""
        name: str = payload.get("name", "Citizen")
        event_label: str = payload.get("event_label", "life event")
        actions: List[Dict[str, str]] = payload.get("actions", [])
        schemes: List[Dict[str, str]] = payload.get("eligible_schemes", [])
        auto_docs: List[str] = payload.get("auto_verified_docs", [])
        pending_docs: List[str] = payload.get("pending_docs", [])
        needs_approval: bool = payload.get("requires_human_approval", False)

        bullet = "\u2022"
        lines: List[str] = [
            f"Dear {name},",
            "",
            f"We noticed an important life event: {event_label}. "
            "You do not need to apply separately — the government has automatically "
            "started the right services for you.",
            "",
            "Services activated on your behalf:",
        ]
        lines += [f"  {bullet} {a['department']}: {a['action']}" for a in actions] or [f"  {bullet} (none)"]

        lines += ["", "Benefits you qualify for:"]
        if schemes:
            lines += [f"  {bullet} {s['name']} — {s['reason']}" for s in schemes]
        else:
            lines += [f"  {bullet} No matching benefit schemes for this event/profile."]

        lines += ["", "Documents we already verified for you:"]
        lines += [f"  {bullet} {d}" for d in auto_docs] or [f"  {bullet} (none)"]

        lines += ["", "Documents still needed from you:"]
        lines += [f"  {bullet} {d}" for d in pending_docs] or [f"  {bullet} (none — you're all set!)"]

        if needs_approval:
            lines += [
                "",
                "Note: Because this is a sensitive event, a government officer will "
                "review and approve the actions before they are finalized.",
            ]

        lines += ["", "Warm regards,", "Citizen Services (Automated)"]
        return "\n".join(lines)


class OpenAIAdapter(ReasoningEngine):
    """OPTIONAL adapter, enabled only when OPENAI_API_KEY is set AND openai installed."""

    name = "OpenAIAdapter"

    def __init__(self) -> None:
        # Lazy import so the base project never requires the openai package.
        from openai import OpenAI  # type: ignore

        self._client = OpenAI(api_key=settings.openai_api_key)
        self._model = settings.openai_model
        self._fallback = MockLLM()

    def generate(self, task: str, payload: Dict[str, Any]) -> str:
        try:
            prompt = (
                "You are a government citizen-services assistant. Write a short, "
                "warm, plain-language message for the citizen based on this JSON "
                f"context:\n{payload}"
            )
            resp = self._client.chat.completions.create(
                model=self._model,
                messages=[{"role": "user", "content": prompt}],
            )
            return (resp.choices[0].message.content or "").strip()
        except Exception:  # noqa: BLE001 - never break the demo on network/API errors.
            return self._fallback.generate(task, payload)


def get_reasoning_engine() -> ReasoningEngine:
    """Factory: OpenAI adapter if configured & importable, otherwise the MockLLM."""
    if settings.openai_enabled:
        try:
            return OpenAIAdapter()
        except Exception:  # noqa: BLE001 - openai not installed or init failed.
            return MockLLM()
    return MockLLM()
