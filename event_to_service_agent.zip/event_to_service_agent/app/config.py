"""Application configuration via pydantic-settings (all values optional)."""
from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Runtime settings loaded from environment variables or an optional .env file."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    app_name: str = "Event-to-Service Agent"

    # Optional OpenAI configuration. If openai_api_key is empty (default),
    # the system uses the fully-offline MockLLM.
    openai_api_key: str = ""
    openai_model: str = "gpt-4o-mini"

    @property
    def openai_enabled(self) -> bool:
        """True only when an API key has been explicitly provided."""
        return bool(self.openai_api_key.strip())


# Singleton settings instance imported across the app.
settings = Settings()
