"""AgentContext (shared state) and AgentPipeline (sequential orchestrator)."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, TYPE_CHECKING

from app.models import (
    ActionItem,
    Citizen,
    EligibleScheme,
    EventRequest,
    ReasoningStep,
    RequiredDocument,
    Scheme,
)
from app.reasoning import ReasoningEngine

if TYPE_CHECKING:  # Avoid a runtime circular import with agents.
    from app.agents.base import BaseAgent


@dataclass
class AgentContext:
    """Mutable state object passed between all agents in the pipeline."""

    request: EventRequest
    citizen: Citizen
    schemes: List[Scheme]
    engine: ReasoningEngine

    event_label: str = ""
    requires_human_approval: bool = False
    eligible_schemes: List[EligibleScheme] = field(default_factory=list)
    action_plan: List[ActionItem] = field(default_factory=list)
    required_documents: List[RequiredDocument] = field(default_factory=list)
    citizen_message: str = ""
    trace: List[ReasoningStep] = field(default_factory=list)

    def log(self, agent: str, thought: str, output: Any) -> None:
        """Append a transparency/audit entry to the reasoning trace."""
        self.trace.append(ReasoningStep(agent=agent, thought=thought, output=output))


class AgentPipeline:
    """Runs a fixed sequence of agents, threading a single AgentContext through them."""

    def __init__(self, agents: List["BaseAgent"]) -> None:
        self.agents = agents

    def run(self, ctx: AgentContext) -> AgentContext:
        """Execute each agent in order and return the enriched context."""
        for agent in self.agents:
            agent.run(ctx)
        return ctx
