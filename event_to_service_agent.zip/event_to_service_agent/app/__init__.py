"""Event-to-Service Agent — Agentic AI for proactive government services."""

__version__ = "1.0.0"
