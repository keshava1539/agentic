"""FastAPI application: mock DB, endpoints, and the 5-agent pipeline wiring."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.agents import (
    CommunicationAgent,
    DocumentAgent,
    EligibilityAgent,
    EventDetectionAgent,
    ServiceOrchestratorAgent,
)
from app.config import settings
from app.models import (
    Citizen,
    CitizenDetail,
    EventRequest,
    EventResponse,
    HealthResponse,
    Scheme,
)
from app.pipeline import AgentContext, AgentPipeline
from app.reasoning import get_reasoning_engine
from app.rules import LIFE_EVENTS

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "data" / "seed_data.json"
STATIC_DIR = BASE_DIR.parent / "static"


class InMemoryDB:
    """Simple in-process store for citizens, schemes, and activation history."""

    def __init__(self) -> None:
        self.citizens: Dict[str, Citizen] = {}
        self.schemes: List[Scheme] = []
        self.history: Dict[str, List[dict]] = {}

    def seed(self) -> None:
        raw = json.loads(DATA_PATH.read_text(encoding="utf-8"))
        self.citizens = {c["id"]: Citizen(**c) for c in raw["citizens"]}
        self.schemes = [Scheme(**s) for s in raw["schemes"]]
        self.history = {cid: [] for cid in self.citizens}


db = InMemoryDB()
db.seed()

# Build the agent pipeline once (agents are stateless w.r.t. context).
pipeline = AgentPipeline(
    agents=[
        EventDetectionAgent(),
        EligibilityAgent(),
        ServiceOrchestratorAgent(),
        DocumentAgent(),
        CommunicationAgent(),
    ]
)

app = FastAPI(title=settings.app_name, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    """Liveness probe."""
    return HealthResponse(status="ok")


@app.get("/", include_in_schema=False)
def index() -> FileResponse:
    """Serve the citizen dashboard."""
    return FileResponse(str(STATIC_DIR / "index.html"))


@app.get("/citizens", response_model=List[Citizen])
def list_citizens() -> List[Citizen]:
    """Return all seeded citizens."""
    return list(db.citizens.values())


@app.get("/citizens/{citizen_id}", response_model=CitizenDetail)
def get_citizen(citizen_id: str) -> CitizenDetail:
    """Return a citizen profile plus their activated-services history."""
    citizen = db.citizens.get(citizen_id)
    if citizen is None:
        raise HTTPException(status_code=404, detail=f"Citizen '{citizen_id}' not found.")
    return CitizenDetail(
        citizen=citizen,
        activated_services_history=db.history.get(citizen_id, []),
    )


@app.get("/schemes", response_model=List[Scheme])
def list_schemes() -> List[Scheme]:
    """Return the full catalog of government schemes."""
    return db.schemes


@app.post("/events", response_model=EventResponse)
def handle_event(request: EventRequest) -> EventResponse:
    """Run the full 5-agent pipeline for an incoming life event."""
    citizen = db.citizens.get(request.citizen_id)
    if citizen is None:
        raise HTTPException(
            status_code=404, detail=f"Citizen '{request.citizen_id}' not found."
        )

    if request.event_type not in LIFE_EVENTS:
        raise HTTPException(
            status_code=400,
            detail=f"Unknown event_type '{request.event_type}'. "
            f"Supported: {LIFE_EVENTS}",
        )

    ctx = AgentContext(
        request=request,
        citizen=citizen,
        schemes=db.schemes,
        engine=get_reasoning_engine(),
    )
    pipeline.run(ctx)

    response = EventResponse(
        citizen_id=citizen.id,
        citizen_name=citizen.name,
        event_type=request.event_type,
        event_label=ctx.event_label,
        requires_human_approval=ctx.requires_human_approval,
        eligible_schemes=ctx.eligible_schemes,
        action_plan=ctx.action_plan,
        required_documents=ctx.required_documents,
        citizen_message=ctx.citizen_message,
        reasoning_trace=ctx.trace,
    )

    db.history.setdefault(citizen.id, []).append(
        {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "event_type": request.event_type,
            "event_label": ctx.event_label,
            "requires_human_approval": ctx.requires_human_approval,
            "activated_departments": sorted({a.department for a in ctx.action_plan}),
            "eligible_schemes": [s.name for s in ctx.eligible_schemes],
        }
    )

    return response
