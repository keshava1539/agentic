"""Agent 3: coordinate departments and build an ordered action plan."""
from __future__ import annotations

from typing import List

from app.agents.base import BaseAgent
from app.models import ActionItem
from app.pipeline import AgentContext
from app.rules import EVENT_SERVICE_MAP


class ServiceOrchestratorAgent(BaseAgent):
    """Turns the event->service map into a concrete, ordered cross-department plan."""

    name = "ServiceOrchestratorAgent"

    def run(self, ctx: AgentContext) -> None:
        mapping = EVENT_SERVICE_MAP[ctx.request.event_type]
        # Sensitive events pause at 'pending_approval' for human oversight.
        status = "pending_approval" if ctx.requires_human_approval else "initiated"

        plan: List[ActionItem] = [
            ActionItem(
                order=i,
                department=action["department"],
                action=action["action"],
                status=status,
            )
            for i, action in enumerate(mapping["actions"], start=1)
        ]

        ctx.action_plan = plan
        ctx.log(
            self.name,
            "Coordinated departments "
            f"{mapping['departments']} into a {len(plan)}-step action plan "
            f"(status={status}).",
            [a.model_dump() for a in plan],
        )
