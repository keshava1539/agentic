"""Agent 4: auto-collect existing records; list required vs pending documents."""
from __future__ import annotations

from typing import List

from app.agents.base import BaseAgent
from app.models import RequiredDocument
from app.pipeline import AgentContext
from app.rules import EVENT_SERVICE_MAP


class DocumentAgent(BaseAgent):
    """Marks documents already on file as auto-verified; the rest as pending."""

    name = "DocumentAgent"

    def run(self, ctx: AgentContext) -> None:
        mapping = EVENT_SERVICE_MAP[ctx.request.event_type]
        docs: List[RequiredDocument] = []

        for doc in mapping["documents"]:
            record_key = doc.get("record_key")
            if record_key and record_key in ctx.citizen.records:
                docs.append(
                    RequiredDocument(
                        name=doc["name"],
                        status="auto_verified",
                        source="Government Records",
                    )
                )
            else:
                docs.append(
                    RequiredDocument(
                        name=doc["name"],
                        status="pending",
                        source="Citizen Upload Required",
                    )
                )

        ctx.required_documents = docs
        auto = sum(1 for d in docs if d.status == "auto_verified")
        ctx.log(
            self.name,
            f"Auto-verified {auto}/{len(docs)} documents from existing government "
            "records; remaining documents flagged as pending.",
            [d.model_dump() for d in docs],
        )
