"""Agent 5: generate a plain-language summary for the citizen."""
from __future__ import annotations

from app.agents.base import BaseAgent
from app.pipeline import AgentContext


class CommunicationAgent(BaseAgent):
    """Uses the ReasoningEngine to compose a citizen-friendly notification."""

    name = "CommunicationAgent"

    def run(self, ctx: AgentContext) -> None:
        auto_docs = [d.name for d in ctx.required_documents if d.status == "auto_verified"]
        pending_docs = [d.name for d in ctx.required_documents if d.status == "pending"]

        payload = {
            "name": ctx.citizen.name,
            "event_label": ctx.event_label,
            "actions": [a.model_dump() for a in ctx.action_plan],
            "eligible_schemes": [s.model_dump() for s in ctx.eligible_schemes],
            "auto_verified_docs": auto_docs,
            "pending_docs": pending_docs,
            "requires_human_approval": ctx.requires_human_approval,
        }

        ctx.citizen_message = ctx.engine.generate("citizen_message", payload)
        ctx.log(
            self.name,
            f"Generated citizen notification using {ctx.engine.name}.",
            {"message_preview": ctx.citizen_message[:120] + "..."},
        )
