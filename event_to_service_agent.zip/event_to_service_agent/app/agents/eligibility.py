"""Agent 2: match the citizen profile against scheme eligibility rules."""
from __future__ import annotations

from typing import List

from app.agents.base import BaseAgent
from app.models import EligibleScheme
from app.pipeline import AgentContext


class EligibilityAgent(BaseAgent):
    """Evaluates each scheme triggered by the event against the citizen's profile."""

    name = "EligibilityAgent"

    def run(self, ctx: AgentContext) -> None:
        citizen = ctx.citizen
        event_type = ctx.request.event_type
        matched: List[EligibleScheme] = []

        for scheme in ctx.schemes:
            if event_type not in scheme.event_triggers:
                continue

            reasons: List[str] = []
            qualifies = True

            # Age check
            if scheme.min_age <= citizen.age <= scheme.max_age:
                reasons.append(f"age {citizen.age} within {scheme.min_age}-{scheme.max_age}")
            else:
                qualifies = False

            # Income check
            if citizen.income <= scheme.max_income:
                reasons.append(f"income {int(citizen.income)} <= {int(scheme.max_income)}")
            else:
                qualifies = False

            # Disability requirement
            if scheme.requires_disability:
                if citizen.disability:
                    reasons.append("disability status confirmed")
                else:
                    qualifies = False

            if qualifies:
                matched.append(
                    EligibleScheme(
                        scheme_id=scheme.id,
                        name=scheme.name,
                        department=scheme.department,
                        reason="; ".join(reasons),
                    )
                )

        ctx.eligible_schemes = matched
        ctx.log(
            self.name,
            f"Evaluated schemes triggered by '{event_type}'. "
            f"{len(matched)} scheme(s) matched the citizen's profile.",
            [s.model_dump() for s in matched],
        )
