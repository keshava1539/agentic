"""Agent 1: validate & classify the incoming life event and extract entities."""
from __future__ import annotations

from app.agents.base import BaseAgent
from app.pipeline import AgentContext
from app.rules import EVENT_LABELS, SENSITIVE_EVENTS


class EventDetectionAgent(BaseAgent):
    """Classifies the event and flags whether human approval is required."""

    name = "EventDetectionAgent"

    def run(self, ctx: AgentContext) -> None:
        event_type = ctx.request.event_type
        ctx.event_label = EVENT_LABELS.get(event_type, event_type)
        ctx.requires_human_approval = event_type in SENSITIVE_EVENTS

        ctx.log(
            self.name,
            f"Detected and classified life event '{event_type}' "
            f"({ctx.event_label}). Extracted citizen and event entities.",
            {
                "citizen_id": ctx.request.citizen_id,
                "event_type": event_type,
                "event_label": ctx.event_label,
                "event_data": ctx.request.event_data,
                "requires_human_approval": ctx.requires_human_approval,
            },
        )
