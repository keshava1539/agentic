"""Abstract base class shared by all agents."""
from __future__ import annotations

from abc import ABC, abstractmethod

from app.pipeline import AgentContext


class BaseAgent(ABC):
    """Every agent reads from and writes to the shared AgentContext."""

    name: str = "BaseAgent"

    @abstractmethod
    def run(self, ctx: AgentContext) -> None:
        """Perform this agent's work and log a reasoning-trace entry."""
        raise NotImplementedError
