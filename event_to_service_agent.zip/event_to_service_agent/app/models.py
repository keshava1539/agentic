"""Pydantic request/response schemas shared across the application."""
from __future__ import annotations

from typing import Any, Dict, List

from pydantic import BaseModel, Field


class Citizen(BaseModel):
    """A citizen profile stored in the mock database."""

    id: str
    name: str
    age: int
    income: float
    employment_status: str
    dependents: int
    disability: bool
    marital_status: str
    address: str
    records: List[str] = Field(default_factory=list)


class Scheme(BaseModel):
    """A government scheme/benefit with simple eligibility rules."""

    id: str
    name: str
    department: str
    description: str
    event_triggers: List[str]
    min_age: int = 0
    max_age: int = 200
    max_income: float = 1_000_000_000_000.0
    requires_disability: bool = False


class EventRequest(BaseModel):
    """Incoming life-event payload for POST /events."""

    citizen_id: str
    event_type: str
    event_data: Dict[str, Any] = Field(default_factory=dict)


class ReasoningStep(BaseModel):
    """A single audit-trace entry produced by an agent (governance/transparency)."""

    agent: str
    thought: str
    output: Any


class EligibleScheme(BaseModel):
    """A scheme the citizen qualifies for, with a human-readable reason."""

    scheme_id: str
    name: str
    department: str
    reason: str


class ActionItem(BaseModel):
    """An ordered step in the cross-department service orchestration plan."""

    order: int
    department: str
    action: str
    status: str


class RequiredDocument(BaseModel):
    """A document needed for the event, with auto-verification status."""

    name: str
    status: str
    source: str


class EventResponse(BaseModel):
    """Full structured result returned by the 5-agent pipeline."""

    citizen_id: str
    citizen_name: str
    event_type: str
    event_label: str
    requires_human_approval: bool
    eligible_schemes: List[EligibleScheme]
    action_plan: List[ActionItem]
    required_documents: List[RequiredDocument]
    citizen_message: str
    reasoning_trace: List[ReasoningStep]


class CitizenDetail(BaseModel):
    """Citizen profile plus a history of previously activated services."""

    citizen: Citizen
    activated_services_history: List[Dict[str, Any]]


class HealthResponse(BaseModel):
    status: str
