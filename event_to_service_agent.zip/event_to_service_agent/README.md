# Event-to-Service Agent

**Agentic AI for Government - "Government Reaches Citizens Before Citizens Ask for Help"**

A multi-agent system that detects a citizen **life event** (child birth, job loss,
retirement, disability, marriage, relocation, death) and **automatically orchestrates
the relevant public services** - instead of citizens applying manually.

Runs **100% offline** with a rule-based `MockLLM` (no paid API keys, no database).
An optional OpenAI adapter can be enabled if you provide a key.

---

## Architecture (ASCII)

```
                         POST /events {citizen_id, event_type, event_data}
                                             |
                                             v
                                  +--------------------+
                                  |    AgentPipeline    |  (shared AgentContext)
                                  +--------------------+
                                             |
   +--------------+---------------+----------+--------+---------------+---------------+
   v              v               v                   v               v
[1] Event     [2] Eligibility  [3] Service         [4] Document    [5] Communication
 Detection      Agent           Orchestrator        Agent           Agent
 classify &    match profile    build ordered       auto-verify vs  plain-language
 flag sensitive vs scheme rules cross-dept plan     pending docs    citizen message
   |              |               |                   |               |
   +--------------+---------------+----------+--------+---------------+
                                             v
                        Structured result + full reasoning/audit trace
                        + requires_human_approval flag  --->  Dashboard
```

**Reasoning layer:** `ReasoningEngine` interface -> `MockLLM` (default, offline) or
`OpenAIAdapter` (optional). Selected at runtime by `get_reasoning_engine()`.

---

## Setup & Run

```bash
cd event_to_service_agent
python -m venv .venv
# Windows: .venv\Scripts\activate   |   macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open **http://127.0.0.1:8000** for the dashboard.
API docs (Swagger): **http://127.0.0.1:8000/docs**

---

## Example curl commands

```bash
# Health
curl http://127.0.0.1:8000/health

# List citizens
curl http://127.0.0.1:8000/citizens

# Citizen profile + history
curl http://127.0.0.1:8000/citizens/C001

# All schemes
curl http://127.0.0.1:8000/schemes

# Trigger a life event (runs the full 5-agent pipeline)
curl -X POST http://127.0.0.1:8000/events \
  -H "Content-Type: application/json" \
  -d '{"citizen_id":"C001","event_type":"child_birth","event_data":{"child_name":"Aarav"}}'

# Sensitive event -> requires_human_approval = true
curl -X POST http://127.0.0.1:8000/events \
  -H "Content-Type: application/json" \
  -d '{"citizen_id":"C003","event_type":"disability","event_data":{}}'
```

---

## Governance features
- **Reasoning/audit trace** in every `/events` response (one entry per agent).
- **`requires_human_approval`** flag auto-set for sensitive events (`death`, `disability`);
  their action plan items are held at status `pending_approval`.
- Deterministic MockLLM keeps behaviour explainable and reproducible.

---

## Optionally enable OpenAI (not required)
The base project never imports `openai`. To try the adapter:

```bash
pip install openai
export OPENAI_API_KEY=sk-your-key   # Windows: set OPENAI_API_KEY=sk-your-key
export OPENAI_MODEL=gpt-4o-mini     # optional
uvicorn app.main:app --reload
```

If the key is missing or the package/network fails, the system **automatically falls
back to the offline MockLLM** - the demo always works.

---

## Supported events -> departments (summary)

| Event         | Departments involved                       |
|---------------|--------------------------------------------|
| child_birth   | Identity, Health, Welfare, Communication   |
| job_loss      | Welfare, Tax, Communication                |
| retirement    | Welfare, Health, Tax, Communication        |
| disability *  | Health, Welfare, Identity, Communication   |
| marriage      | Identity, Tax, Communication               |
| relocation    | Identity, Health, Education, Communication |
| death *       | Identity, Welfare, Tax, Communication      |

`*` = requires human approval.

---

## Project structure
```
event_to_service_agent/
|-- app/
|   |-- main.py            # FastAPI app, in-memory DB, endpoints
|   |-- config.py          # pydantic-settings
|   |-- models.py          # pydantic schemas
|   |-- reasoning.py       # MockLLM + optional OpenAI adapter
|   |-- pipeline.py        # AgentContext + AgentPipeline
|   |-- rules.py           # event->service + scheme rules
|   |-- agents/            # 5 agent classes
|   `-- data/seed_data.json
|-- static/index.html      # single-file dashboard
|-- requirements.txt
|-- .env.example
`-- README.md
```
