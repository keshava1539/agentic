# AegisAI — Intelligent Reverse Proxy (v1.0 core)

AI-assisted reverse proxy with deterministic rules + AI slow-path, adaptive rate
limiting, circuit breaker, backpressure, graceful degradation, metrics and dashboard.

## Run

    npm install
    node src/demo-backend.js       # terminal 1: upstream on :9000
    npm start                      # terminal 2: proxy on :8080, admin on :8081

## Test

    curl http://127.0.0.1:8080/api/hello
    curl "http://127.0.0.1:8080/search?q=1' OR '1'='1"   # blocked
    open http://127.0.0.1:8081/                          # dashboard

## Architecture

- **Fast path**: rule engine (SQLi/XSS/prompt-injection regex, header + UA checks)
  runs on the URL and a streamed body sample.
- **Slow path**: uncertain requests are scored by an AI worker-thread pool
  (ONNX-ready hook, heuristic default) so the main event loop never blocks.
- **Risk engine**: weighted fusion of rule/AI/header/entropy signals -> ALLOW or BLOCK.
- **Resilience**: adaptive token-bucket rate limiting, bounded-queue backpressure (429),
  circuit breaker (503), graceful degradation when AI is offline.
- **Observability**: structured JSON logs (pino), Prometheus `/metrics`, `/stats` JSON,
  and a live HTML dashboard.

## Streaming

The proxy captures only the first `inspectBytes` of a request body for inspection and
streams the remainder straight through, giving constant memory usage even for multi-GB
uploads.

## Optional Redis

Set `redis.enabled: true` in `config/default.yaml` (or `REDIS_ENABLED=true`).
It falls back to an in-memory store automatically if Redis is unreachable.

## Optional real ONNX model

See `src/worker/inference-worker.js` for the drop-in hook using `onnxruntime-node`.

## Endpoints (admin :8081)

| Path       | Purpose                             |
|------------|-------------------------------------|
| `/`        | Live dashboard                      |
| `/stats`   | JSON metrics snapshot               |
| `/metrics` | Prometheus-compatible metrics       |
| `/health`  | Health + circuit + store kind       |

## Project structure

    aegis-ai/
    ├── package.json
    ├── config/default.yaml
    ├── rules/{sqli,xss,promptInjection,headers}.json
    ├── public/index.html
    ├── src/
    │   ├── index.js  config.js  logger.js  store.js  metrics.js
    │   ├── rate-limiter.js  circuit-breaker.js
    │   ├── rule-engine.js  risk-engine.js  worker-pool.js
    │   ├── proxy.js  admin.js  demo-backend.js
    │   └── worker/inference-worker.js
    └── README.md

Licensed for educational / portfolio use.
