import pino from "pino";

export function createLogger({ level = "info", pretty = true } = {}) {
  if (pretty) {
    try {
      return pino({
        level,
        transport: {
          target: "pino-pretty",
          options: { colorize: true, translateTime: "SYS:standard", ignore: "pid,hostname" },
        },
      });
    } catch {
      /* pino-pretty not installed -> plain JSON logs */
    }
  }
  return pino({ level });
}
