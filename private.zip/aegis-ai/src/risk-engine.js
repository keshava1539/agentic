const clamp01 = (x) => Math.max(0, Math.min(1, x));

export class RiskEngine {
  constructor({ blockThreshold, slowPathLow }) {
    this.blockThreshold = blockThreshold;
    this.slowPathLow = slowPathLow;
  }
  // Uncertain band -> send to AI slow path.
  needsSlowPath(ruleScore) {
    return ruleScore >= this.slowPathLow && ruleScore < this.blockThreshold;
  }
  evaluate({ ruleScore = 0, aiScore = 0, headerScore = 0, entropy = 0 }) {
    const entropyFlag = entropy > 6 ? clamp01((entropy - 6) / 2) : 0;
    const risk = clamp01(
      0.45 * ruleScore + 0.30 * aiScore + 0.15 * headerScore + 0.10 * entropyFlag
    );
    return { risk: +risk.toFixed(3), decision: risk >= this.blockThreshold ? "BLOCK" : "ALLOW" };
  }
}
