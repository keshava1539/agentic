import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const RULES_DIR = path.resolve(__dirname, "../rules");

// Probabilistic OR: combine independent match confidences.
function probOr(scores) {
  return 1 - scores.reduce((acc, s) => acc * (1 - s), 1);
}

export class RuleEngine {
  constructor(logger) {
    this.logger = logger;
    this.sets = [];
    this.headers = { required: [], suspiciousUserAgents: [] };
    this.load();
  }
  load() {
    for (const f of ["sqli.json", "xss.json", "promptInjection.json"]) {
      try {
        const raw = JSON.parse(fs.readFileSync(path.join(RULES_DIR, f), "utf8"));
        this.sets.push({
          name: raw.name,
          patterns: raw.patterns.map((p) => ({ ...p, re: new RegExp(p.regex, "i") })),
        });
      } catch (e) {
        this.logger?.warn({ file: f, err: e.message }, "rule set load failed");
      }
    }
    try {
      this.headers = JSON.parse(fs.readFileSync(path.join(RULES_DIR, "headers.json"), "utf8"));
    } catch { /* optional */ }
  }
  scanText(text) {
    if (!text) return { score: 0, matches: [] };
    const matches = [];
    for (const set of this.sets) {
      for (const p of set.patterns) {
        if (p.re.test(text)) matches.push({ set: set.name, id: p.id, weight: p.weight });
      }
    }
    return { score: probOr(matches.map((m) => m.weight)), matches };
  }
  scanHeaders(headers) {
    const matches = [];
    for (const req of this.headers.required || []) {
      if (!headers[req]) matches.push({ id: `missing-${req}`, weight: 0.4 });
    }
    const ua = String(headers["user-agent"] || "").toLowerCase();
    if (!ua) matches.push({ id: "missing-ua", weight: 0.3 });
    for (const bad of this.headers.suspiciousUserAgents || []) {
      if (ua.includes(bad)) matches.push({ id: `ua-${bad}`, weight: 0.7 });
    }
    return { score: probOr(matches.map((m) => m.weight)), matches };
  }
}
