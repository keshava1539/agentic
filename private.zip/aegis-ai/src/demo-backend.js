// A trivial upstream to prove end-to-end forwarding works.
import http from "node:http";

const port = process.env.BACKEND_PORT || 9000;
http.createServer((req, res) => {
  let size = 0;
  req.on("data", (c) => (size += c.length));
  req.on("end", () => {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({
      msg: "hello from backend",
      method: req.method,
      path: req.url,
      requestId: req.headers["x-request-id"] || null,
      bytesReceived: size,
    }));
  });
}).listen(port, () => console.log(`demo backend -> http://127.0.0.1:${port}`));
