import { Worker } from "node:worker_threads";

export class QueueFullError extends Error {
  constructor() { super("worker queue full"); this.code = "QUEUE_FULL"; }
}

export class WorkerPool {
  constructor({ size, maxQueue, logger }) {
    this.size = size;
    this.maxQueue = maxQueue;
    this.logger = logger;
    this.workerURL = new URL("./worker/inference-worker.js", import.meta.url);
    this.workers = [];
    this.idle = [];
    this.queue = [];
    this.pending = new Map();
    this.seq = 0;
    this.degraded = false;
  }
  init() { for (let i = 0; i < this.size; i++) this.spawn(i); }
  spawn(id) {
    const w = new Worker(this.workerURL);
    w._id = id;
    w.on("message", (msg) => this.onMessage(w, msg));
    w.on("error", (e) => this.onError(w, e));
    w.on("exit", (code) => { if (code !== 0) this.onError(w, new Error("exit " + code)); });
    this.workers.push(w);
    this.idle.push(w);
  }
  onMessage(w, msg) {
    const p = this.pending.get(msg.id);
    if (p) { this.pending.delete(msg.id); p.resolve(msg.score); }
    this.idle.push(w);
    this.drain();
  }
  onError(w, e) {
    this.logger?.error({ err: e.message, worker: w._id }, "worker error -> respawning");
    for (const [id, p] of this.pending) {
      if (p.worker === w) { this.pending.delete(id); p.reject(e); }
    }
    this.workers = this.workers.filter((x) => x !== w);
    this.idle = this.idle.filter((x) => x !== w);
    try { w.terminate(); } catch {}
    try { this.spawn(w._id); this.degraded = false; }
    catch { if (this.workers.length === 0) this.degraded = true; }
  }
  run(task) {
    return new Promise((resolve, reject) => {
      if (this.workers.length === 0) return reject(new Error("AI_DEGRADED"));
      if (this.queue.length >= this.maxQueue) return reject(new QueueFullError());
      this.queue.push({ task, resolve, reject });
      this.drain();
    });
  }
  drain() {
    while (this.idle.length && this.queue.length) {
      const w = this.idle.shift();
      const job = this.queue.shift();
      const id = ++this.seq;
      this.pending.set(id, { resolve: job.resolve, reject: job.reject, worker: w });
      w.postMessage({ id, text: job.task.text });
    }
  }
  stats() {
    return {
      size: this.workers.length,
      busy: this.workers.length - this.idle.length,
      queued: this.queue.length,
      degraded: this.degraded,
    };
  }
  async shutdown() { await Promise.all(this.workers.map((w) => w.terminate().catch(() => {}))); }
}
