export class CircuitBreaker {
  constructor({ failureThreshold = 5, resetMs = 10000 } = {}) {
    this.failureThreshold = failureThreshold;
    this.resetMs = resetMs;
    this.failures = 0;
    this.state = "CLOSED";
    this.openUntil = 0;
  }
  canRequest() {
    if (this.state === "OPEN") {
      if (Date.now() >= this.openUntil) { this.state = "HALF_OPEN"; return true; }
      return false;
    }
    return true;
  }
  onSuccess() { this.failures = 0; this.state = "CLOSED"; }
  onFailure() {
    this.failures++;
    if (this.failures >= this.failureThreshold) {
      this.state = "OPEN";
      this.openUntil = Date.now() + this.resetMs;
    }
  }
}
