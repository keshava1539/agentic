import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import yaml from "js-yaml";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const DEFAULTS = {
  server: { host: "0.0.0.0", port: 8080 },
  admin: { port: 8081 },
  backend: { target: "http://127.0.0.1:9000", timeoutMs: 15000 },
  proxy: { inspectBytes: 65536 },
  workers: { size: 0 },
  queue: { maxSize: 1000 },
  rateLimit: { capacity: 100, refillPerSec: 20, suspiciousCost: 10 },
  riskEngine: { blockThreshold: 0.75, slowPathLow: 0.35 },
  circuitBreaker: { failureThreshold: 5, resetMs: 10000 },
  redis: { enabled: false, url: "redis://127.0.0.1:6379" },
  logging: { level: "info", pretty: true },
};

function deepMerge(base, extra) {
  const out = Array.isArray(base) ? [...base] : { ...base };
  for (const k of Object.keys(extra || {})) {
    if (extra[k] && typeof extra[k] === "object" && !Array.isArray(extra[k])) {
      out[k] = deepMerge(base[k] || {}, extra[k]);
    } else {
      out[k] = extra[k];
    }
  }
  return out;
}

export function loadConfig() {
  let cfg = structuredClone(DEFAULTS);
  const file = path.resolve(__dirname, "../config/default.yaml");
  try {
    const y = yaml.load(fs.readFileSync(file, "utf8"));
    cfg = deepMerge(cfg, y || {});
  } catch {
    /* use defaults if file missing/invalid */
  }
  if (process.env.PORT) cfg.server.port = Number(process.env.PORT);
  if (process.env.BACKEND_TARGET) cfg.backend.target = process.env.BACKEND_TARGET;
  if (process.env.REDIS_ENABLED) cfg.redis.enabled = process.env.REDIS_ENABLED === "true";
  if (process.env.REDIS_URL) cfg.redis.url = process.env.REDIS_URL;
  return cfg;
}
