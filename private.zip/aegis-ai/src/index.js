import os from "node:os";
import { loadConfig } from "./config.js";
import { createLogger } from "./logger.js";
import { createStore } from "./store.js";
import { Metrics } from "./metrics.js";
import { RuleEngine } from "./rule-engine.js";
import { RiskEngine } from "./risk-engine.js";
import { RateLimiter } from "./rate-limiter.js";
import { CircuitBreaker } from "./circuit-breaker.js";
import { WorkerPool } from "./worker-pool.js";
import { createProxyServer } from "./proxy.js";
import { createAdminServer } from "./admin.js";

async function main() {
  const cfg = loadConfig();
  const logger = createLogger(cfg.logging);

  const store = await createStore(cfg, logger);
  const metrics = new Metrics();
  const ruleEngine = new RuleEngine(logger);
  const riskEngine = new RiskEngine(cfg.riskEngine);
  const rateLimiter = new RateLimiter(store, cfg.rateLimit);
  const cb = new CircuitBreaker(cfg.circuitBreaker);

  const poolSize = cfg.workers.size > 0 ? cfg.workers.size : Math.max(2, os.cpus().length);
  const workerPool = new WorkerPool({ size: poolSize, maxQueue: cfg.queue.maxSize, logger });
  workerPool.init();
  logger.info({ workers: poolSize }, "AI worker pool ready");

  const deps = { ruleEngine, riskEngine, rateLimiter, workerPool, cb, metrics, logger };

  const proxy = createProxyServer(cfg, deps);
  proxy.listen(cfg.server.port, cfg.server.host, () =>
    logger.info(`AegisAI proxy -> http://${cfg.server.host}:${cfg.server.port} (backend ${cfg.backend.target})`)
  );

  const admin = createAdminServer({ metrics, pool: workerPool, cb, store });
  admin.listen(cfg.admin.port, () =>
    logger.info(`Admin/Dashboard -> http://127.0.0.1:${cfg.admin.port}  (/metrics, /stats, /health)`)
  );

  const shutdown = async (sig) => {
    logger.info({ sig }, "shutting down gracefully");
    proxy.close(); admin.close();
    await workerPool.shutdown();
    await store.close();
    process.exit(0);
  };
  process.on("SIGINT", () => shutdown("SIGINT"));
  process.on("SIGTERM", () => shutdown("SIGTERM"));
  process.on("uncaughtException", (e) => logger.error({ err: e.message }, "uncaughtException"));
  process.on("unhandledRejection", (e) => logger.error({ err: String(e) }, "unhandledRejection"));
}

main().catch((e) => { console.error("fatal:", e); process.exit(1); });
