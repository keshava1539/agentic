import http from "node:http";
import https from "node:https";
import { PassThrough, Readable, pipeline } from "node:stream";
import { randomUUID } from "node:crypto";
import { QueueFullError } from "./worker-pool.js";

const safeDecode = (s) => { try { return decodeURIComponent(s); } catch { return s; } };

function entropy(buf) {
  if (!buf.length) return 0;
  const freq = new Array(256).fill(0);
  for (const b of buf) freq[b]++;
  let e = 0;
  for (const f of freq) if (f) { const p = f / buf.length; e -= p * Math.log2(p); }
  return e;
}

// Stream the body while capturing an inspection sample of the first N bytes.
function prepareBody(req, inspectLimit) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0, settled = false;
    const cleanup = () => { req.off("data", onData); req.off("end", onEnd); req.off("error", onErr); };
    const onData = (chunk) => {
      chunks.push(chunk); size += chunk.length;
      if (size >= inspectLimit) {
        cleanup(); req.pause();
        const pass = new PassThrough();
        for (const c of chunks) pass.write(c);
        req.pipe(pass); // stream the remainder -> constant memory
        settled = true;
        resolve({ sample: Buffer.concat(chunks), body: pass });
      }
    };
    const onEnd = () => {
      if (settled) return; settled = true; cleanup();
      const buf = Buffer.concat(chunks);
      resolve({ sample: buf, body: Readable.from(buf.length ? [buf] : []) });
    };
    const onErr = (e) => { if (settled) return; settled = true; cleanup(); reject(e); };
    req.on("data", onData); req.on("end", onEnd); req.on("error", onErr);
  });
}

function sendJson(res, code, obj) {
  if (res.headersSent) return;
  const body = JSON.stringify(obj);
  res.writeHead(code, { "content-type": "application/json", "x-request-id": obj.requestId || "" });
  res.end(body);
}

function forward(cfg, req, bodyStream, res, deps, requestId) {
  const { cb, metrics, logger } = deps;
  const target = new URL(cfg.backend.target);
  const lib = target.protocol === "https:" ? https : http;
  const started = Date.now();

  const options = {
    protocol: target.protocol,
    hostname: target.hostname,
    port: target.port || (target.protocol === "https:" ? 443 : 80),
    method: req.method,
    path: req.url,
    timeout: cfg.backend.timeoutMs,
    headers: {
      ...req.headers,
      host: target.host,
      "x-request-id": requestId,
      "x-forwarded-for": req.socket.remoteAddress,
    },
  };

  const upstream = lib.request(options, (upRes) => {
    if (upRes.statusCode >= 500) { cb.onFailure(); metrics.inc("backendErrors"); }
    else cb.onSuccess();
    metrics.observe("backendLatency", Date.now() - started);
    res.writeHead(upRes.statusCode, upRes.headers);
    pipeline(upRes, res, (err) => { if (err) logger.debug({ err: err.message }, "downstream pipe error"); });
  });

  upstream.on("timeout", () => upstream.destroy(new Error("upstream timeout")));
  upstream.on("error", (e) => {
    cb.onFailure(); metrics.inc("backendErrors");
    logger.warn({ err: e.message, requestId }, "backend error");
    sendJson(res, 502, { error: "bad_gateway", requestId });
  });

  pipeline(bodyStream, upstream, (err) => { if (err) upstream.destroy(err); });
}

export function createProxyServer(cfg, deps) {
  const { ruleEngine, riskEngine, rateLimiter, workerPool, cb, metrics, logger } = deps;

  const server = http.createServer(async (req, res) => {
    const requestId = randomUUID();
    const ip = req.socket.remoteAddress || "unknown";
    const t0 = Date.now();
    metrics.inc("requests");
    metrics.addGauge("activeConnections", 1);
    res.on("close", () => metrics.addGauge("activeConnections", -1));

    try {
      // ---------- FAST PATH: headers + URL ----------
      const urlText = safeDecode(req.url);
      const headerScan = ruleEngine.scanHeaders(req.headers);
      const urlScan = ruleEngine.scanText(urlText);

      // ---------- Body sample (streaming) ----------
      let sample = Buffer.alloc(0), body;
      try {
        const prepared = await prepareBody(req, cfg.proxy.inspectBytes);
        sample = prepared.sample; body = prepared.body;
      } catch (e) {
        return sendJson(res, 400, { error: "bad_request", requestId });
      }

      const sampleText = sample.toString("utf8");
      const bodyScan = ruleEngine.scanText(sampleText);
      const ent = entropy(sample);
      const ruleScore = 1 - (1 - urlScan.score) * (1 - bodyScan.score);
      const headerScore = headerScan.score;

      // ---------- Adaptive rate limiting ----------
      const suspicious = ruleScore > 0.3 || headerScore > 0.3;
      const cost = suspicious ? cfg.rateLimit.suspiciousCost : 1;
      const rl = await rateLimiter.consume(ip, cost);
      if (!rl.allowed) {
        metrics.inc("rateLimited");
        logger.info({ requestId, ip, decision: "RATE_LIMIT" }, "rate limited");
        res.setHeader("retry-after", "1");
        return sendJson(res, 429, { error: "too_many_requests", requestId });
      }

      // ---------- SLOW PATH: AI inference for the uncertain band ----------
      let aiScore = 0;
      if (riskEngine.needsSlowPath(ruleScore)) {
        try {
          const aiT0 = Date.now();
          aiScore = await workerPool.run({ text: (urlText + "\n" + sampleText).slice(0, 4096) });
          metrics.inc("aiInferences");
          metrics.observe("aiLatency", Date.now() - aiT0);
        } catch (e) {
          if (e instanceof QueueFullError) { // backpressure
            metrics.inc("rateLimited");
            return sendJson(res, 429, { error: "server_busy", requestId });
          }
          logger.warn({ requestId }, "AI degraded -> rule-engine only"); // graceful degradation
        }
      }

      // ---------- RISK ENGINE: final decision ----------
      const { risk, decision } = riskEngine.evaluate({ ruleScore, aiScore, headerScore, entropy: ent });

      logger.info({ requestId, ip, method: req.method, path: req.url,
        ruleScore: +ruleScore.toFixed(2), aiScore, risk,
        worker: workerPool.stats().busy, latency: Date.now() - t0, decision }, "request");

      if (decision === "BLOCK") {
        metrics.inc("blocked");
        metrics.observe("totalLatency", Date.now() - t0);
        return sendJson(res, 403, { error: "blocked", risk, requestId });
      }

      // ---------- Circuit breaker + forward ----------
      if (!cb.canRequest()) {
        metrics.observe("totalLatency", Date.now() - t0);
        return sendJson(res, 503, { error: "service_unavailable", requestId });
      }

      metrics.inc("allowed");
      forward(cfg, req, body, res, deps, requestId);
      res.on("finish", () => metrics.observe("totalLatency", Date.now() - t0));
    } catch (e) {
      metrics.inc("errors");
      logger.error({ err: e.message, requestId }, "handler error");
      sendJson(res, 500, { error: "internal_error", requestId });
    }
  });

  return server;
}
