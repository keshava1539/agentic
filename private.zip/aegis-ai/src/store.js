// Distributed state with graceful in-memory fallback.
class MemoryStore {
  constructor() { this.map = new Map(); }
  async getJSON(k) {
    const e = this.map.get(k);
    if (!e) return null;
    if (e.exp && Date.now() > e.exp) { this.map.delete(k); return null; }
    return e.v;
  }
  async setJSON(k, v, ttlSec) {
    this.map.set(k, { v, exp: ttlSec ? Date.now() + ttlSec * 1000 : 0 });
  }
  get kind() { return "memory"; }
  async close() {}
}

class RedisStore {
  constructor(client) { this.c = client; }
  async getJSON(k) { const s = await this.c.get(k); return s ? JSON.parse(s) : null; }
  async setJSON(k, v, ttlSec = 3600) { await this.c.set(k, JSON.stringify(v), "EX", ttlSec); }
  get kind() { return "redis"; }
  async close() { try { await this.c.quit(); } catch {} }
}

export async function createStore(cfg, logger) {
  if (cfg.redis?.enabled) {
    try {
      const { default: Redis } = await import("ioredis");
      const client = new Redis(cfg.redis.url, { lazyConnect: true, maxRetriesPerRequest: 2 });
      await client.connect();
      logger.info("Store: connected to Redis");
      return new RedisStore(client);
    } catch (e) {
      logger.warn({ err: e.message }, "Store: Redis unavailable -> in-memory fallback");
    }
  }
  logger.info("Store: using in-memory store");
  return new MemoryStore();
}
