// Token-bucket, adaptive cost. Backed by the shared store (Redis or memory).
export class RateLimiter {
  constructor(store, { capacity, refillPerSec }) {
    this.store = store;
    this.capacity = capacity;
    this.refill = refillPerSec;
  }
  async consume(key, cost = 1) {
    const now = Date.now();
    const k = "rl:" + key;
    const st = (await this.store.getJSON(k)) || { tokens: this.capacity, ts: now };
    const elapsed = (now - st.ts) / 1000;
    st.tokens = Math.min(this.capacity, st.tokens + elapsed * this.refill);
    st.ts = now;
    let allowed = false;
    if (st.tokens >= cost) { st.tokens -= cost; allowed = true; }
    await this.store.setJSON(k, st, 3600);
    return { allowed, remaining: Math.floor(st.tokens) };
  }
}
