import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DASHBOARD = path.resolve(__dirname, "../public/index.html");

export function createAdminServer({ metrics, pool, cb, store }) {
  return http.createServer((req, res) => {
    if (req.url === "/health") {
      return res.writeHead(200, { "content-type": "application/json" })
        .end(JSON.stringify({ status: "ok", circuit: cb.state, store: store.kind }));
    }
    if (req.url === "/metrics") {
      return res.writeHead(200, { "content-type": "text/plain" }).end(metrics.toPrometheus(pool));
    }
    if (req.url === "/stats") {
      return res.writeHead(200, { "content-type": "application/json" })
        .end(JSON.stringify({ ...metrics.snapshot(pool), circuit: cb.state }));
    }
    if (req.url === "/" || req.url === "/index.html") {
      try {
        return res.writeHead(200, { "content-type": "text/html" }).end(fs.readFileSync(DASHBOARD));
      } catch {
        return res.writeHead(200, { "content-type": "text/plain" }).end("AegisAI admin");
      }
    }
    res.writeHead(404).end("not found");
  });
}
