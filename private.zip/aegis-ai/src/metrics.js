export class Metrics {
  constructor() {
    this.counters = {
      requests: 0, allowed: 0, blocked: 0, rateLimited: 0,
      aiInferences: 0, backendErrors: 0, errors: 0,
    };
    this.gauges = { activeConnections: 0 };
    this.hist = { totalLatency: [], aiLatency: [], backendLatency: [] };
    this.start = Date.now();
  }
  inc(k, v = 1) { this.counters[k] = (this.counters[k] || 0) + v; }
  setGauge(k, v) { this.gauges[k] = v; }
  addGauge(k, v) { this.gauges[k] = (this.gauges[k] || 0) + v; }
  observe(k, v) { const a = this.hist[k]; a.push(v); if (a.length > 1000) a.shift(); }
  pct(a, p) {
    if (!a.length) return 0;
    const s = [...a].sort((x, y) => x - y);
    return s[Math.min(s.length - 1, Math.floor((p / 100) * s.length))];
  }
  rps() {
    const secs = (Date.now() - this.start) / 1000;
    return secs > 0 ? +(this.counters.requests / secs).toFixed(2) : 0;
  }
  snapshot(pool) {
    return {
      uptimeSec: Math.round((Date.now() - this.start) / 1000),
      rps: this.rps(),
      ...this.counters,
      activeConnections: this.gauges.activeConnections,
      latency: {
        p50: this.pct(this.hist.totalLatency, 50),
        p95: this.pct(this.hist.totalLatency, 95),
        p99: this.pct(this.hist.totalLatency, 99),
      },
      ai: { p95: this.pct(this.hist.aiLatency, 95) },
      backend: { p95: this.pct(this.hist.backendLatency, 95) },
      worker: pool ? pool.stats() : null,
    };
  }
  toPrometheus(pool) {
    const s = pool ? pool.stats() : { size: 0, busy: 0, queued: 0 };
    const lines = [];
    const g = (n, v, h) => lines.push(`# HELP ${n} ${h}\n# TYPE ${n} gauge\n${n} ${v}`);
    for (const [k, v] of Object.entries(this.counters)) g(`aegis_${k}_total`, v, k);
    g("aegis_active_connections", this.gauges.activeConnections, "active connections");
    g("aegis_requests_per_second", this.rps(), "requests per second");
    g("aegis_queue_size", s.queued, "worker queue depth");
    g("aegis_worker_pool_size", s.size, "worker pool size");
    g("aegis_worker_busy", s.busy, "busy workers");
    g("aegis_latency_p50_ms", this.pct(this.hist.totalLatency, 50), "p50 latency");
    g("aegis_latency_p95_ms", this.pct(this.hist.totalLatency, 95), "p95 latency");
    g("aegis_latency_p99_ms", this.pct(this.hist.totalLatency, 99), "p99 latency");
    return lines.join("\n") + "\n";
  }
}
