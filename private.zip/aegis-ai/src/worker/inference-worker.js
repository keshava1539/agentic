import { parentPort } from "node:worker_threads";

/* ---------------------------------------------------------------------------
 * REAL ONNX HOOK (optional):
 *   import * as ort from "onnxruntime-node";
 *   const session = await ort.InferenceSession.create("./model/threat.onnx");
 *   ...tokenize text -> run session -> return probability
 * The heuristic below is a drop-in stand-in so the system runs without a model.
 * ------------------------------------------------------------------------- */

const PROMPT_INJECTION = [
  /ignore (all )?(previous|prior|above) instructions/i,
  /system prompt/i,
  /(dan mode|jailbreak|developer mode)/i,
  /reveal your (instructions|prompt|rules)/i,
  /disregard .*(rules|policy|guidelines)/i,
];

const SUSPICIOUS = /(union select|drop table|<script|onerror=|\bexec\b|eval\(|base64_decode)/gi;

function classify(text) {
  const t = (text || "").toLowerCase();
  let score = 0;
  for (const re of PROMPT_INJECTION) if (re.test(t)) score = Math.max(score, 0.85);
  const hits = (t.match(SUSPICIOUS) || []).length;
  score = Math.max(score, Math.min(0.9, hits * 0.25));
  // long, high-density blob -> possible obfuscated payload
  if (t.length > 500 && /[a-z0-9+/]{200,}/i.test(t)) score = Math.max(score, 0.6);
  return Math.min(1, +score.toFixed(3));
}

parentPort.on("message", ({ id, text }) => {
  const score = classify(text);
  parentPort.postMessage({ id, score });
});
